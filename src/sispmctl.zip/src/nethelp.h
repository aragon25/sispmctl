#ifndef NETHELP_H
#define NETHELP_H

int sock_write_bytes(int sockfd, const unsigned char *buff, int len);

#endif /* ! NETHELP_H */
